rm -r -f $HOME/.multichain/chaindemo
#echo $HOME
